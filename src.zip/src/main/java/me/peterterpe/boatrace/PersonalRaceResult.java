package me.peterterpe.boatrace;

import java.time.Instant;

public class PersonalRaceResult {
    private long elapsed;
    private Instant timestamp;

    public PersonalRaceResult() {}
    public PersonalRaceResult(long elapsed, Instant timestamp) {
        this.elapsed = elapsed;
        this.timestamp = timestamp;
    }

    public long elapsed() { return elapsed; }
    public Instant timestamp() { return timestamp; }
}
