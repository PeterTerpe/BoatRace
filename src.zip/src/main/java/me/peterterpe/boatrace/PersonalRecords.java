package me.peterterpe.boatrace;

import java.util.UUID;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.time.Instant;
import java.util.Comparator;

public class PersonalRecords {
    private UUID playerId;
    private int attempts = 0;
    private final Map<String, List<PersonalTrackRecord>> trackRecords = new HashMap<>();
    private static PersonalRecords instance;
    public static PersonalRecords getInstance() {
        if (instance == null) {
            instance = new PersonalRecords();
        }
        return instance;
    }

    public PersonalRecords() {}

    public void recordTime(String trackName, long elapsedMs) {
        attempts++;
        trackRecords.computeIfAbsent(trackName, k -> new ArrayList<>());
        List<PersonalRaceResult> recs = trackRecords.get(trackName);
        recs.add(new PersonalRaceResult(elapsedMs, Instant.now()));
        recs.sort(Comparator.comparingLong(PersonalRaceResult::elapsed));
        if (recs.size() > 5) recs.subList(5, recs.size()).clear();
    }

    public UUID getPlayerID() { return playerId; }
    public int getAttemps() { return attempts; }
    public List<PersonalRaceResult> gPersonalRaceResults(String trackName) {
        return trackRecords.get(trackName);
    }

    public String seri
}
