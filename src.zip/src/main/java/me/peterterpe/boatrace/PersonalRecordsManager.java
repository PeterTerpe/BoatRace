package me.peterterpe.boatrace;

public class PersonalRecordsManager {
    private Map<UUID, >
}
