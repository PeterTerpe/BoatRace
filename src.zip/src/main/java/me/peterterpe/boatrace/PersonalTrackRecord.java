package me.peterterpe.boatrace;

import java.util.ArrayList;
import java.util.List;

public class PersonalTrackRecord {
    int attempts = 0;
    List<PersonalRaceResult> best = new ArrayList<>();

    public PersonalTrackRecord() {}
}
